خطوات تشغيل Firebase وSearch Console

1) Firebase:
 - console.firebase.google.com > Add project.
 - Build > Authentication > Sign-in method > فعّل Email/Password.
 - Build > Firestore Database > Create database (Production mode).
 - Firestore > Rules: الصق محتوى firestore.rules (وغيّر OWNER_UID) ثم Publish.
 - Project settings > Your apps > Web (</>) > انسخ الإعدادات وحطها في js/firebase-config.js.
 - Authentication > Settings > Authorized domains: ضيف دومين موقعك.
 - مهم: الموقع لازم يتفتح من استضافة (Firebase Hosting أو غيرها) مش بدبل-كليك على الملف.
 - الطلبات بتظهر في Firestore > orders.

2) Search Console:
 - في sitemap.xml وrobots.txt بدّل YOUR-DOMAIN.com بدومينك الحقيقي.
 - ارفع الموقع، ثم في Search Console أضف الدومين وأرسل https://دومينك/sitemap.xml من قسم Sitemaps.

3) التقييمات:
 - التقييمات الجديدة بتتسجل في Firestore > reviews بحالة approved=false.
 - عشان تظهر على الموقع: افتح التقييم وغيّر approved إلى true.
 - التقييمات الظاهرة حالياً في js/reviews-data.js تجريبية، استبدلها بتقييمات حقيقية.
