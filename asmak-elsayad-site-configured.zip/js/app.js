const IMG=new Proxy({},{get:(_,k)=>'images/'+k+'.jpg'});
const $=id=>document.getElementById(id);
const get=k=>{try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}};
const set=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
$('yr').textContent=new Date().getFullYear();
function paint(){const u=get('sy_cur'),b=$('authBtn');b.textContent=u?('أهلاً '+u.name+' · خروج'):'تسجيل الدخول';
b.onclick=()=>{if(!u){location.href='login.html';return}if(window.SY&&SY.enabled)SY.logout().then(()=>location.reload());else{try{localStorage.removeItem('sy_cur')}catch(e){}location.reload()}}}
paint();addEventListener('sy-auth',paint);
